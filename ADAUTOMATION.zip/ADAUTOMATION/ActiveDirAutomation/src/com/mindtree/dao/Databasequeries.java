package com.mindtree.dao;
import java.sql.*;
import java.text.*;
import java.util.ArrayList;
import java.util.Date;

import org.apache.commons.dbutils.DbUtils;

import com.mindtree.entity.Historyofusers;
import com.mindtree.entity.UserListEntity;
import com.mindtree.entity.userDetailsEntity;
import com.mindtree.utilities.ConnectionEstablishment;

public class Databasequeries {


	ConnectionEstablishment connection=new ConnectionEstablishment();
 int value;
 
public int update(String options,int time,String username) throws ClassNotFoundException, SQLException {
	Connection con =null;
	Statement stmt = null;
	//Statement stmt;
	System.out.println("into update");
		try {
			con=ConnectionEstablishment.getConnection();
			System.out.println("connection property"+ con.getClientInfo());
			
			 stmt = con.createStatement();
		
		System.out.println("connection while inserting: " +con);

	int is_approved = 0;
		
		 DateFormat dateformat=new SimpleDateFormat("EEE, d MMM  HH:mm aaa");
		 Date date=new Date();
		 String request_time_out=dateformat.format(date);
		String sql="insert into user_request(username,ADGroup,duration,date,is_approved) values('"+username+"','"+options+"','"+time+"','"+request_time_out+"','"+is_approved+"')";
	    

			value = stmt.executeUpdate(sql);
			System.out.println("inside try" + connection +stmt); 
			System.out.println(stmt.isClosed());
			System.out.println(con.isClosed());
			//stmt.close();
			//con.close();
			System.out.println(stmt.isClosed());
			System.out.println(con.isClosed());
			
		//	con=ConnectionEstablishment.closeConnection(con);
			//System.out.println("inside try after close" + con ); 
			/*if(stmt.isClosed()) {
				
			}else
				System.out.println("inside else");
				connection.closeConnection(stmt);
			System.out.println("after close stmt"+stmt);*/
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			
			connection.releaseConnection(con, stmt);
		}
	    /*System.out.println(value);*/
	    System.out.println("inserted successfully");
	    
	    //connection.closeConnection(con);
	     
	
	 
	
	/*stmt.close();
	ConnectionEstablishment.closeConnection(con);*/
  //releaseConnection(con, stmt);
	//System.out.println("inside try after close" + con + stmt);
	//finally {
	//releaseConnection(con,stmt);
	//con.close();
	//stmt.close();
	//System.out.println("inside finally" +con + stmt);
//}
	return value;
}

public ArrayList<UserListEntity> retriveUsers() throws ClassNotFoundException, SQLException{
	Connection con=ConnectionEstablishment.getConnection();
	Statement statement = con.createStatement();
	ArrayList<UserListEntity> list = new ArrayList<UserListEntity>();
	try {
	
	String uName;
	String date;
	//statement = ((Connection) connection).createStatement();
	String userList = "select distinct(username),date from user_request where is_approved=0 group by userName";
	 ResultSet rs = statement.executeQuery(userList);
	 while(rs.next()){
		 uName=rs.getString(1);
		 date=rs.getString(2);
		 list.add(new UserListEntity(uName, date));
	 }
	 /*rs.close();
	 statement.close();*/
	 ConnectionEstablishment.closeConnection(con);
	}
	catch (Exception e) {
		// TODO: handle exception
	}
	 //connection.closeConnection(con);
	finally {
		connection.releaseConnection(con, statement);
	}
	return list;
	
}

public ArrayList<userDetailsEntity> retrive(String userName) throws ClassNotFoundException, SQLException{
	
	Connection con=ConnectionEstablishment.getConnection();
	Statement statement = con.createStatement();
		ArrayList<userDetailsEntity> list = new ArrayList<userDetailsEntity>();
	try {
		
		//int no;
		String uName;
		String ADGroup;
		int duration;
		String date;
		
		
		 String userGroup = "select * from user_request where username="+"'"+userName+"' and is_approved=0";
		 ResultSet rs = statement.executeQuery(userGroup);
		 while (rs.next()) {
			   // no = rs.getInt(1);
				uName = rs.getString(2);
				ADGroup = rs.getString(3);
				duration = rs.getInt(4);
				date = rs.getString(5);
				
				list.add(new userDetailsEntity(uName,ADGroup,duration,date));
			}
		 System.out.println(rs.getFetchSize());
		 /*rs.close();
		 statement.close();
		 connection.closeConnection(con);*/
	}
	catch (Exception e) {
		// TODO: handle exception
	}
	finally {
		connection.releaseConnection(con, statement);
	}
		 
	return list;
	
}

public void update(String userName,int time,String[] adGroup) throws SQLException, ClassNotFoundException {
	Connection con=connection.getConnection();
	Statement stmt=con.createStatement();
	try {
		//stmt=((Connection) connection).createStatement();
		System.out.println("update method");
		for(int i=0;i<adGroup.length;i++) {
			//String sql = "update user_request set is_approved=1  where username='"+userName+"'";
			String sql1 = "update user_request set duration='"+time+"',ADGroup='"+adGroup[i]+"',is_approved=1  where username='"+userName+"'";
			//stmt.executeUpdate(sql);
			stmt.executeUpdate(sql1);
			
	}
		/*stmt.close();
		connection.closeConnection(con);*/
	}
		catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	
	
	}
	finally {
		connection.releaseConnection(con, stmt);
	}
}
public void insertlog(String username,String[] adGroup,int time) throws SQLException, ClassNotFoundException {
	
	Connection con=connection.getConnection();
	Statement stmt=con.createStatement();
	try {
	//stmt=((Connection) connection).createStatement();
	System.out.println("insertlog");
	String adminname=System.getProperty("user.name");
	 DateFormat dateformat=new SimpleDateFormat("EEE, d MMM  HH:mm aaa");
	 Date date=new Date();
	 String request_time_out=dateformat.format(date);
	 for(int i=0;i<adGroup.length;i++) {
			
			String sql1 = "insert into logs(username,ADGroup,date,approvalname,duration) values('"+username+"','"+adGroup[i]+"','"+request_time_out+"','"+adminname+"','"+time+"')";
			stmt.executeUpdate(sql1);
			
	 }
	 System.out.println("inserted into logs");
	 /*stmt.close();
	 connection.closeConnection(con);*/
	}
	catch (Exception e) {
		// TODO: handle exception
	}
	finally {
		connection.releaseConnection(con, stmt);
	}
}
public ArrayList<Historyofusers> retrievelogs() throws ClassNotFoundException, SQLException {
	Connection con=connection.getConnection();
	Statement stmt=con.createStatement();
	ArrayList<Historyofusers> list = new ArrayList<Historyofusers>();
	String username;
	String ADGroup;
	String date;
	String approvalname;
	int duration;
	
	try {
		//stmt=((Connection) connection).createStatement();
		System.out.println("retrievelog");
		String sql="select * from logs";
		 ResultSet rs = stmt.executeQuery(sql);
		 System.out.println("checking");
		 System.out.println("rs value:"+rs.getFetchSize());
		 while(rs.next()) {
			 username=rs.getString(1);
			 ADGroup=rs.getString(2);
			 date=rs.getString(3);
			 approvalname=rs.getString(4);
			 duration=rs.getInt(5);
			 list.add(new Historyofusers(username, ADGroup, date, approvalname, duration));
		 }
		/* rs.close();
		 stmt.close();
		connection.closeConnection(con);*/
		
	}catch(Exception e) {
		System.out.println("into catch of retrieve logs");
		e.printStackTrace();
	}
	finally {
		connection.releaseConnection(con, stmt);
	}
	return list;
}
	
}
