package com.mindtree.Service;

import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.DirContext;
import javax.naming.directory.ModificationItem;
import javax.naming.ldap.LdapContext;
import javax.servlet.http.HttpSession;


public class AddUserToGroups {
	//HttpSession session;
	ADConnection adConnection = new ADConnection();
	LdapContext ldap= null;
	HttpSession session;
	public void addGroups(String userName,String[] groups) throws NamingException {
	    
		//String userName=(String)session.getAttribute("userName");
		String uName = "CN="+userName+",CN=Users,DC=AD,DC=DEMO"; 
		System.out.println("username:"+userName);
		ldap = adConnection.getADConnect();
		System.out.println("ctx call :"+ldap);
for(int i=0;i<groups.length;i++){
	String groupName = "CN="+groups[i]+",CN=Users,DC=AD,DC=DEMO";
	System.out.println(groupName);
	ModificationItem[] mods = new ModificationItem[1];
	Attribute mod =new BasicAttribute("member",uName);
	mods[0] =new ModificationItem(DirContext.ADD_ATTRIBUTE, mod);
	ldap.modifyAttributes(groupName, mods);
}

System.out.println("group added successfully");
	}
}
