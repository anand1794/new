package com.mindtree.Service;

public class GetUserName {

	public String getUserName(){		
		String user=System.getProperty("user.name"); 
		return user;
	//	System.out.println("username : "+user);
	}
}
