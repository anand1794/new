package com.mindtree.Service;

import java.util.ArrayList;
import java.util.Iterator;

import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.LdapContext;

import com.mindtree.entity.GroupEntity;

public class GetGroups {

	public static String usersContainer = "CN=Users,DC=AD,DC=DEMO";
	//String uName = "CN="+userName+usersContainer;
	//public static final String userName = "CN=balaji,CN=Users,DC=AD,DC=AUTOMATION";
	
	public GroupEntity getGroups(LdapContext ctx,String userName) throws NamingException{
		GroupEntity groupEntity = new GroupEntity();
		 ArrayList<String> userpresentingroup=new ArrayList<String>();
	        ArrayList<String> usernotpresentingroup=new ArrayList<String>();
		SearchControls ctls = new SearchControls();
        String[] attrIDs = { "CN" };
        ctls.setReturningAttributes(attrIDs);
        ctls.setSearchScope(SearchControls.SUBTREE_SCOPE);
        NamingEnumeration answer = ctx.search(usersContainer, "(objectclass=group)", ctls);
        while (answer.hasMore()) {
            SearchResult rslt = (SearchResult) answer.next();
            Attributes attrs = rslt.getAttributes();
            String name = attrs.get("CN").toString().substring(4);
        // System.out.println(name);
        
        
        String gName = "CN="+name+","+usersContainer;
     
       // System.out.println(gName);
        DirContext lookedContext = (DirContext) (ctx.lookup(gName));
        Attribute attrs1 = lookedContext.getAttributes("").get("member");
        Boolean value = checkGroup(attrs1,userName);
      //  System.out.println(value);
        if(value==true){
        	if(name.contains("loreal")) {
        	userpresentingroup.add(name);
        	}
        }
        else{
        	if(name.contains("loreal")) {
        	usernotpresentingroup.add(name);
        	}
        }
        }
        groupEntity.setUserpresentingroup(userpresentingroup);
        groupEntity.setUsernotpresentingroup(usernotpresentingroup);
        Iterator itr=userpresentingroup.iterator();
        Iterator itr1=usernotpresentingroup.iterator();
      //  System.out.println(" ");
        System.out.println("user accessed groups");
        while(itr.hasNext()){
        	
        	System.out.println(itr.next());
        }
        System.out.println(" ");
        System.out.println("user not accessed groups");
        while(itr1.hasNext()){
        	
        	System.out.println(itr1.next());
        }
		return groupEntity;
	}

	private Boolean checkGroup(Attribute attrs1,String userName) throws NamingException {
		//check if user is in that group
		//System.out.println(attrs1);
		String uName = "CN="+userName+","+usersContainer;
		//System.out.println("username is"+uName);
	//System.out.println("inside method");
  	  if(attrs1!=null){
  	 
  	   for (int i = 0; i < attrs1.size(); i++) {
  	    String foundMember = (String) attrs1.get(i);
  	  //  System.out.println(foundMember);
  	   // System.out.println(uName);
  	    if(foundMember.equals(uName)) {
  	     return true;
  	    }
  	  }
  	  }
	return false;
	}
}
