package com.mindtree.Service;

import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.Name;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.DirContext;
import javax.naming.directory.ModificationItem;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;

public class ADConnection {
	public static void main(String args[]) throws NamingException {
		ADConnection adConnection = new ADConnection();
		adConnection.getADConnect();
	}

	public LdapContext getADConnect() throws NamingException {
		Hashtable env = new Hashtable();
		env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
		env.put(Context.SECURITY_AUTHENTICATION, "simple");
		env.put(Context.SECURITY_PRINCIPAL, "CN=naresh,OU=Domain Controllers,DC=AD,DC=DEMO");
		env.put(Context.SECURITY_CREDENTIALS, "Mindtree@123");
		env.put(Context.PROVIDER_URL, "ldap://WIN-55IN3EA9KKP.AD.DEMO:389");
		LdapContext ctx = null;
		try {
			System.out.println("inside try");
			 ctx = new InitialLdapContext(env, null);
			 System.out.println("Connection Successful.");
			
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		/* ModificationItem[] mods = new ModificationItem[1];
			Attribute mod =new BasicAttribute("member",userName);
			mods[0] =new ModificationItem(DirContext.ADD_ATTRIBUTE, mod);
			ctx.modifyAttributes(groupName, mods);
			System.out.println("group added successfully");*/
		
		return ctx;
	}
}
