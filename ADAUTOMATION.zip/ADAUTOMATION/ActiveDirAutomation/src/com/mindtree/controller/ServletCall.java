package com.mindtree.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mindtree.dao.Databasequeries;

/**
 * Servlet implementation class ServletCall
 */
@WebServlet("/UserForm")
public class ServletCall extends HttpServlet {
	private static final long serialVersionUID = 1L;
       Databasequeries database=new Databasequeries();
	private int value;
    
    public ServletCall() {
        super();
      
    }

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		/*System.out.println("coming inside the controller goGet method");
		response.getWriter().append("Served at: ").append(request.getContextPath());*/
	//rocess(request,response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
		HttpSession session=request.getSession();
		String[] options=request.getParameterValues("ad");
		System.out.println(options[0]);
		int time=Integer.parseInt(request.getParameter("time"));
		System.out.println(time);
		session.setAttribute("duration",time);
		ArrayList al=new ArrayList();
		al=(ArrayList) session.getAttribute("usergroup");
		
		String username=(String) session.getAttribute("userName");
		for(int i=0;i<options.length;i++){
			//System.out.println(options[i] +" "+time+" "+username);
		    value = database.update(options[i],time,username); 
			
		}
		//process(request,response);
		if(value==1){
		request.setAttribute("message", "request has been send");
		request.getRequestDispatcher("assets/requestform.jsp").forward(request, response);
		}else
		{
			request.setAttribute("message", "problem in sending request");
			request.getRequestDispatcher("assets/requestform.jsp").forward(request, response);
		}
	}
	catch(Exception e) {
		request.setAttribute("message", "problem in sending request");
		request.getRequestDispatcher("assets/requestform.jsp").forward(request, response);
		
	}
	}
	
	
}

