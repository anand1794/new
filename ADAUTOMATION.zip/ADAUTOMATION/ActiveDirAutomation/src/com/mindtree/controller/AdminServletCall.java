package com.mindtree.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.NamingException;
import javax.naming.ldap.LdapContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mindtree.Service.ADConnection;
import com.mindtree.Service.GetGroups;
import com.mindtree.Service.GetUserName;
import com.mindtree.dao.Databasequeries;
import com.mindtree.entity.GroupEntity;
import com.mindtree.entity.UserListEntity;
import com.mindtree.entity.userDetailsEntity;

/**
 * Servlet implementation class AdminServletCall
 */
@WebServlet("/admin")
public class AdminServletCall extends HttpServlet {
	private static final long serialVersionUID = 1L;
       ADConnection ad=new ADConnection();
       GetUserName gt=new GetUserName();
       GetGroups gd=new GetGroups();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdminServletCall() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	try {
		try {
			process(request,response);
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
	 Databasequeries database=new Databasequeries();
	 ArrayList<UserListEntity> list = new ArrayList<UserListEntity>();
	private void process(HttpServletRequest request, HttpServletResponse response) throws ClassNotFoundException, SQLException, ServletException, IOException, NamingException {
		//HttpSession session=request.getSession();
		//String userName = (String) session.getAttribute("userName");
		System.out.println("inside admin fn call");
		// LdapContext ldap=ad.getADConnect();
		// String username=gt.getUserName();
		// System.out.println("admin name:"+username);
		// GroupEntity groupentity=gd.getGroups(ldap, username);
		// ArrayList<String> list1 = groupentity.getUserpresentingroup();
		 int value =0;
		 /*for (String string : list1) {
	             if(string.equalsIgnoreCase("admin"))
	            	 value=1;
		}
		 if(value==1) {*/
		 list = database.retriveUsers();	
		 System.out.println(list);
		 request.setAttribute("list", list);
			request.getRequestDispatcher("assets/Approval.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			process(request,response);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
