package com.mindtree.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mindtree.Service.AddUserToGroups;
import com.mindtree.dao.Databasequeries;

/**
 * Servlet implementation class ResultServlet
 */
@WebServlet("/AuthenticationPage")
public class ResultServlet extends HttpServlet {
	AddUserToGroups add = new AddUserToGroups();
	Databasequeries database = new Databasequeries();
	private static final long serialVersionUID = 1L;
       HttpSession session;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ResultServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			try {
				process(request,response);
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void process(HttpServletRequest request, HttpServletResponse response) throws NamingException, ServletException, IOException, ClassNotFoundException, SQLException {
		try {
			//int time=Integer.parseInt(request.getParameter("time"));
			System.out.println("into updating the database: result servlet");
		String[] adGroup=request.getParameterValues("grouplist");
		System.out.println("group length:"+adGroup.length);
		int time = Integer.parseInt(request.getParameter("time"));
		String userName=request.getParameter("username");
		System.out.println("username in process:"+userName);
		add.addGroups(userName,adGroup);
		database.update(userName,time,adGroup);
		database.insertlog(userName, adGroup,time);
		request.setAttribute("message", "request has been approved");
		request.getRequestDispatcher("assets/Approval2.jsp").forward(request, response);}
		catch(Exception e) {
			request.setAttribute("message", "request was not been approved");
			request.getRequestDispatcher("assets/Approval2.jsp").forward(request, response);

		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			try {
				process(request,response);
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
