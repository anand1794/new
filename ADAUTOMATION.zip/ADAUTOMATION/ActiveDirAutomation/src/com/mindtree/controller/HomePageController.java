package com.mindtree.controller;

import javax.naming.NamingException;
import javax.naming.ldap.LdapContext;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mindtree.Service.ADConnection;
import com.mindtree.Service.GetGroups;
import com.mindtree.Service.GetUserName;
import com.mindtree.entity.GroupEntity;


/**
 * Servlet implementation class HomePageController
 */
@WebServlet("/")
public class HomePageController extends HttpServlet {
	ADConnection ad = new ADConnection();
	GetUserName getUserName = new GetUserName();
	GetGroups getGroups = new GetGroups();
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public HomePageController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			process(request, response);
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		/*try {
			process(request, response);
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
	}

	private void process(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, NamingException {
		HttpSession session=request.getSession();
		String insert=" ";
		LdapContext ctx = ad.getADConnect();
		System.out.println("ctx: "+ctx);
		String userName = getUserName.getUserName();
		System.out.println("username:"+userName);
		GroupEntity groupEntity = getGroups.getGroups(ctx,userName);
		ArrayList<String> userGroup = groupEntity.getUserpresentingroup();
		ArrayList<String> userNotInGroup = groupEntity.getUsernotpresentingroup();
		System.out.println(userGroup.size());
		System.out.println(userNotInGroup.size());
		int usergrouplength=userGroup.size();
		int usernotgrouplength=userNotInGroup.size();
		if(usergrouplength>usernotgrouplength) {
			for(int k=usernotgrouplength;k<usergrouplength;k++) {
				userNotInGroup.add(k,insert );
			}
		}
		else {
			for(int k=usergrouplength;k<usernotgrouplength;k++) {
				userGroup.add(k,insert);
			}
		}
		System.out.println(userGroup.size());
		System.out.println(userNotInGroup.size());
		session.setAttribute("ctx", ctx);
		request.setAttribute("usergroup", userGroup);
		request.setAttribute("usernotingroup", userNotInGroup);
		session.setAttribute("userName", userName);
		/*
		 * String products = "anand"; System.out.println(products);
		 * request.setAttribute("productsList", products);
		 */
		request.getRequestDispatcher("assets/requestform.jsp").forward(request, response);
	}

}