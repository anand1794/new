package com.mindtree.entity;

public class userDetailsEntity {
//	int no;
String userName;
String ADGroup;
int duration;
String date;
String approvalname;
public userDetailsEntity(String userName, String aDGroup, int duration, String date) {
	super();
	//this.no=no;
	this.userName = userName;
	ADGroup = aDGroup;
	this.duration = duration;
	this.date = date;
}

public userDetailsEntity(String userName, String ADGroup, String date,String approvalname,int duration ) {
	
	//this.no=no;
	this.userName = userName;
	this.ADGroup = ADGroup;
	this.date = date;
	this.approvalname=approvalname;
	this.duration = duration;
	
}


public String getUserName() {
	return userName;
}
public void setUserName(String userName) {
	this.userName = userName;
}
public String getADGroup() {
	return ADGroup;
}
public void setADGroup(String aDGroup) {
	ADGroup = aDGroup;
}
public int getDuration() {
	return duration;
}
public void setDuration(int duration) {
	this.duration = duration;
}
public String getDate() {
	return date;
}
public void setDate(String date) {
	this.date = date;
}


}
