package com.mindtree.entity;

public class Historyofusers {

	String userName;
	String ADGroup;
	int duration;
	String date;
	String approvalname;
	
	public Historyofusers(String userName, String ADGroup, String date,String approvalname,int duration ) {
		
		//this.no=no;
		this.userName = userName;
		this.ADGroup = ADGroup;
		this.date = date;
		this.approvalname=approvalname;
		this.duration = duration;
		
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getADGroup() {
		return ADGroup;
	}

	public void setADGroup(String aDGroup) {
		ADGroup = aDGroup;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getApprovalname() {
		return approvalname;
	}

	public void setApprovalname(String approvalname) {
		this.approvalname = approvalname;
	}
	
	
	
}
