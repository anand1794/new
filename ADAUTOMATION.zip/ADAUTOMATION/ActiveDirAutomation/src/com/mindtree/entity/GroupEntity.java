package com.mindtree.entity;

import java.util.ArrayList;

public class GroupEntity {
	ArrayList<String> userpresentingroup;
    ArrayList<String> usernotpresentingroup;
	public ArrayList<String> getUserpresentingroup() {
		return userpresentingroup;
	}
	public void setUserpresentingroup(ArrayList<String> userpresentingroup) {
		this.userpresentingroup = userpresentingroup;
	}
	public ArrayList<String> getUsernotpresentingroup() {
		return usernotpresentingroup;
	}
	public void setUsernotpresentingroup(ArrayList<String> usernotpresentingroup) {
		this.usernotpresentingroup = usernotpresentingroup;
	}
	public GroupEntity() {
		super();
		// TODO Auto-generated constructor stub
	}
    
}
