package com.mindtree.utilities;

import java.sql.*;
import org.sqlite.*;

public class ConnectionEstablishment {
	// private static ConnectionEstablishment connection=null;
	/*static {
		try {
			//Class.forName("org.sqlite.JDBC");
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException exception) {
			System.out.println("communication failure");
		}
	}*/
	 public static  Connection con=null;
	/* private ConnectionEstablishment() {
		 
		
	 }
	 */
	public static Connection closeConnection(Connection con) throws SQLException {
	//	Connection con = getConnection();
		con=null;
		return con;
	}
	
	public void closeConnection(Statement stmt) throws SQLException {
		//	Connection con = getConnection();
			System.out.println("connection not closed" + stmt);
			stmt.close();
			System.out.println("connection closed" + stmt);
		}

	public static Connection getConnection() {
	 
		
		 try {
			 
				//Class.forName("com.mysql.jdbc.Driver");
				Class.forName("org.sqlite.JDBC");
				String url ="jdbc:sqlite:C:\\Program Files (x86)\\SQLite ODBC Driver\\adautomation.db";
				/*con=DriverManager.getConnection(  
						 "jdbc:mysql://localhost:3306/addatabase","root","root");*/
				con=DriverManager.getConnection(url);
				
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 return con;
	}
	public void releaseConnection(Connection connection, Statement statement) { // Releasing
		// Connection
                     if (connection != null) {
                               try {
                            	   statement.close();
                                    connection.close();
                                    System.out.println("closed?"+ connection.isClosed());
                                   } catch (SQLException exception) {
                                     exception.printStackTrace();
                                    }
                               }
                       
                       System.out.println("inside release connection after close" + connection +statement);
                                  }
	
}
